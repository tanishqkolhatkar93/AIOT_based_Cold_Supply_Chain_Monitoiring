package com.example.cold_chain_monitoring

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

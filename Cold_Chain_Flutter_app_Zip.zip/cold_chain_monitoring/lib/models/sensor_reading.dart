class SensorReading {
  final double temperature;    // °C  (field1)
  final double pressure;       // hPa (field2)
  final double distance;       // cm  (field3)
  final int moisture;          // %   (field4)
  final int spoilageRisk;      // %   (field5)

  final DateTime timestamp;

  SensorReading({
    required this.temperature,
    required this.pressure,
    required this.distance,
    required this.moisture,
    required this.spoilageRisk,
    required this.timestamp,
  });

  factory SensorReading.fromThingSpeak(Map<String, dynamic> feed) {
    double _toDouble(String? s) => double.tryParse(s ?? '') ?? 0;
    int _toInt(String? s) => int.tryParse(s ?? '') ?? 0;

    return SensorReading(
      temperature: _toDouble(feed['field1']),
      pressure: _toDouble(feed['field2']),
      distance: _toDouble(feed['field3']),
      moisture: _toInt(feed['field4']),
      spoilageRisk: _toInt(feed['field5']),
      timestamp: DateTime.parse(feed['created_at']),
    );
  }
}

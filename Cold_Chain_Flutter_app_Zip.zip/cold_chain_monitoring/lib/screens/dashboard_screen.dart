// lib/screens/dashboard_screen.dart
// lib/screens/dashboard_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

import '../models/sensor_reading.dart';
import '../services/cold_chain_api.dart';
import '../services/anomaly_service.dart';
import '../services/notification_service.dart';
import '../utils/risk_utils.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  // For Flutter Web use localhost
//  final AnomalyService _anomalyService = AnomalyService('http://127.0.0.1:5000');

  final AnomalyService _anomalyService =
  AnomalyService(baseUrl: "http://127.0.0.1:5000");


  SensorReading? _latest;
  SensorReading? _previous;
  List<SensorReading> _history = [];
  RiskResult? _risk;
  Timer? _pollTimer;
  bool _loading = false;
  String? _error;

  // anomaly state
  bool _anomalyDetected = false;
  double? _anomalyScore;
  final List<Map<String, dynamic>> _anomalies = [];

  @override
  void initState() {
    super.initState();
    _loadInitial();
    _startPolling();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 20), (_) => _refreshData());
  }

  Future<void> _loadInitial() async {
    setState(() => _loading = true);
    try {
      final list = await ColdChainApi.fetchRecentReadings(results: 20);
      if (list.isNotEmpty) {
        _history = list;
        _latest = list.last;
        _previous = list.length > 1 ? list[list.length - 2] : null;
        _risk = evaluateRisk(_latest!, previous: _previous);
        await _checkAnomalyAndHandle(_latest!);
      }
    } catch (e) {
      _error = 'Failed to load data: $e';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refreshData() async {
    try {
      final list = await ColdChainApi.fetchRecentReadings(results: 20);
      if (list.isNotEmpty) {
        final newLatest = list.last;
        final oldLatest = _latest;
        final risk = evaluateRisk(newLatest, previous: oldLatest);

        if (risk.level != RiskLevel.normal &&
            (_risk == null || risk.message != _risk!.message)) {
          await NotificationService.showAlert(
            title: risk.level == RiskLevel.high ? 'HIGH RISK ALERT' : 'Warning',
            body: risk.message,
          );
        }

        if (mounted) {
          setState(() {
            _history = list;
            _previous = oldLatest;
            _latest = newLatest;
            _risk = risk;
          });
        }

        await _checkAnomalyAndHandle(newLatest);
      }
    } catch (e) {
      debugPrint('refresh error: $e');
    }
  }

  Future<void> _checkAnomalyAndHandle(SensorReading reading) async {
    try {
      final payload = {
        'temperature': reading.temperature,
        'pressure': reading.pressure,
        'distance': reading.distance,
        'moisture': reading.moisture,
        'spoilageRisk': reading.spoilageRisk,
      };

      final res = await _anomalyService.predictSingle(payload);
      final int label = (res['prediction'] is int) ? res['prediction'] as int : int.parse(res['prediction'].toString());
      final double score = (res['score'] is double) ? res['score'] as double : double.parse(res['score'].toString());

      if (label == -1) {
        final entry = {
          'time': DateTime.now().toIso8601String(),
          'reading': payload,
          'prediction': label,
          'score': score,
        };
        setState(() {
          _anomalyDetected = true;
          _anomalyScore = score;
          _anomalies.insert(0, entry);
        });

        await NotificationService.showAlert(
          title: 'Anomaly detected',
          body: 'Model flagged a reading as anomaly (score ${score.toStringAsFixed(3)})',
        );
      } else {
        setState(() => _anomalyDetected = false);
      }
    } catch (e) {
      debugPrint('anomaly predict error: $e');
    }
  }

  Color _riskColor() {
    switch (_risk?.level) {
      case RiskLevel.high:
        return Colors.redAccent;
      case RiskLevel.warning:
        return Colors.orangeAccent;
      case RiskLevel.normal:
      default:
        return Colors.greenAccent.shade400;
    }
  }

  @override
  Widget build(BuildContext context) {
    final latest = _latest;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          title: const Text('Cold Chain Monitor', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          bottom: const TabBar(
            indicatorColor: Colors.cyanAccent,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(icon: Icon(Icons.dashboard_outlined), text: 'Dashboard'),
              Tab(icon: Icon(Icons.show_chart), text: 'History'),
              Tab(icon: Icon(Icons.warning), text: 'Anomalies'),
            ],
          ),
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xff141E30), Color(0xff243B55)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          ),
          child: SafeArea(
            child: TabBarView(
              children: [
                _buildDashboardTab(latest),
                _buildHistoryTab(),
                _buildAnomaliesTab(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ---------------- Tabs ----------------

  Widget _buildDashboardTab(SensorReading? latest) {
    if (_loading && latest == null) {
      return const Center(child: CircularProgressIndicator(color: Colors.white));
    }
    if (latest == null) {
      return Center(child: Text(_error ?? 'No data available', style: const TextStyle(color: Colors.white)));
    }

    return RefreshIndicator(
      onRefresh: _refreshData,
      color: Colors.white,
      backgroundColor: Colors.indigo,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _buildHeader(latest),
          const SizedBox(height: 16),
          _buildRiskGauge(),
          const SizedBox(height: 12),
          if (_anomalyDetected) _buildAnomalyBanner(),
          const SizedBox(height: 12),
          _buildSensorGrid(latest),
          const SizedBox(height: 18),
          _buildAlertBanner(),
        ]),
      ),
    );
  }

  Widget _buildHistoryTab() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: _history.length < 2
          ? const Center(child: Text('Not enough data for history graph.\nSend more data to ThingSpeak.', style: TextStyle(color: Colors.white70), textAlign: TextAlign.center))
          : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Temperature & Risk History', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 16)),
        const SizedBox(height: 8),
        Expanded(child: _buildHistoryChart()),
      ]),
    );
  }

  Widget _buildAnomaliesTab() {
    if (_anomalies.isEmpty) {
      return const Center(child: Text('No anomalies detected yet', style: TextStyle(color: Colors.white70)));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: _anomalies.length,
      separatorBuilder: (_, __) => const Divider(color: Colors.white12),
      itemBuilder: (context, idx) {
        final e = _anomalies[idx];
        final timeLocal = DateTime.parse(e['time']).toLocal().toString();
        final score = e['score'];
        final reading = Map<String, dynamic>.from(e['reading']);
        return Card(
          color: Colors.white.withOpacity(0.04),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            leading: CircleAvatar(backgroundColor: Colors.redAccent, child: const Icon(Icons.warning, color: Colors.white)),
            title: Text('Anomaly — score ${score.toStringAsFixed(3)}', style: const TextStyle(color: Colors.white)),
            subtitle: Text('At $timeLocal\nTemp: ${reading['temperature']}, Moisture: ${reading['moisture']}, Distance: ${reading['distance']}', style: const TextStyle(color: Colors.white70)),
            isThreeLine: true,
            trailing: IconButton(icon: const Icon(Icons.delete, color: Colors.white54), onPressed: () => setState(() => _anomalies.removeAt(idx))),
            onTap: () {},
          ),
        );
      },
    );
  }

  // ---------------- UI Helpers ----------------

  Widget _buildHeader(SensorReading latest) {
    final lastTime = latest.timestamp.toLocal();
    final formatted = '${lastTime.hour.toString().padLeft(2, '0')}:${lastTime.minute.toString().padLeft(2, '0')}:${lastTime.second.toString().padLeft(2, '0')}';
    return Row(children: [
      const Expanded(child: Text('Live Dashboard', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white))),
      Column(crossAxisAlignment: CrossAxisAlignment.end, children: [const Text('Last Update', style: TextStyle(color: Colors.white70, fontSize: 12)), Text(formatted, style: const TextStyle(color: Colors.white, fontSize: 14))])
    ]);
  }

  Widget _buildRiskGauge() {
    final color = _riskColor();
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [color.withOpacity(0.25), color.withOpacity(0.05)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.7), width: 1.5),
      ),
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        Container(width: 70, height: 70, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 6)), alignment: Alignment.center, child: Icon(_risk?.level == RiskLevel.high ? Icons.dangerous : _risk?.level == RiskLevel.warning ? Icons.warning_amber_rounded : Icons.check_circle, color: color, size: 32)),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Spoilage Risk', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)), const SizedBox(height: 4), Text(_risk?.message ?? 'Evaluating...', style: const TextStyle(color: Colors.white70, fontSize: 13))]))
      ]),
    );
  }

  Widget _buildAnomalyBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.red.withOpacity(0.12), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.redAccent)),
      child: Row(children: [
        const Icon(Icons.dangerous, color: Colors.redAccent),
        const SizedBox(width: 10),
        Expanded(child: Text('Anomaly detected by model! Score: ${_anomalyScore?.toStringAsFixed(3) ?? 'N/A'}', style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold))),
        TextButton(onPressed: () => setState(() => _anomalyDetected = false), child: const Text('Dismiss', style: TextStyle(color: Colors.white)))
      ]),
    );
  }

  Widget _buildSensorGrid(SensorReading r) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Live Sensors', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      Wrap(spacing: 12, runSpacing: 12, children: [
        _metricCard(icon: Icons.thermostat, title: 'Temperature', value: '${r.temperature.toStringAsFixed(1)} °C', color: Colors.orangeAccent),
        _metricCard(icon: Icons.compress, title: 'Pressure', value: '${r.pressure.toStringAsFixed(1)} hPa', color: Colors.lightBlueAccent),
        _metricCard(icon: Icons.straighten, title: 'Distance', value: '${r.distance.toStringAsFixed(1)} cm', color: Colors.tealAccent),
        _metricCard(icon: Icons.water_drop, title: 'Moisture', value: '${r.moisture} %', color: Colors.cyanAccent),
        _metricCard(icon: Icons.shield_outlined, title: 'Spoilage Risk', value: '${r.spoilageRisk} %', color: Colors.pinkAccent),
      ])
    ]);
  }

  Widget _metricCard({required IconData icon, required String title, required String value, required Color color}) {
    final width = (MediaQuery.of(context).size.width - 32 - 12) / 2;
    return Container(
      width: width < 200 ? width : width, // responsive
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.08)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 8, offset: const Offset(0, 4))]),
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Container(decoration: BoxDecoration(color: color.withOpacity(0.15), shape: BoxShape.circle), padding: const EdgeInsets.all(8), child: Icon(icon, color: color, size: 20)), const SizedBox(width: 8), Expanded(child: Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)))]),
        const SizedBox(height: 10),
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600))
      ]),
    );
  }

  Widget _buildAlertBanner() {
    if (_risk == null || _risk!.level == RiskLevel.normal) return const SizedBox.shrink();
    final color = _riskColor();
    return Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: color.withOpacity(0.18), borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.8), width: 1)), child: Row(children: [Icon(Icons.notifications_active, color: color), const SizedBox(width: 10), Expanded(child: Text(_risk!.message, style: TextStyle(color: color, fontWeight: FontWeight.w600))) ]));
  }

  Widget _buildHistoryChart() {
    if (_history.length < 2) {
      return const Center(child: Text('Not enough data for history graph.', style: TextStyle(color: Colors.white70, fontSize: 12)));
    }

    final List<FlSpot> spotsTemp = [];
    final List<FlSpot> spotsRisk = [];

    for (int i = 0; i < _history.length; i++) {
      spotsTemp.add(FlSpot(i.toDouble(), _history[i].temperature));
      spotsRisk.add(FlSpot(i.toDouble(), _history[i].spoilageRisk.toDouble()));
    }

    return SizedBox(
      height: 260,
      child: Card(
        color: Colors.white.withOpacity(0.06),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: LineChart(
            LineChartData(
              gridData: FlGridData(
                show: true,
                drawVerticalLine: false,
                horizontalInterval: 2,
                getDrawingHorizontalLine: (value) => FlLine(
                  color: Colors.white.withOpacity(0.1),
                  strokeWidth: 1,
                ),
              ),
              borderData: FlBorderData(
                show: true,
                border: Border.all(color: Colors.white.withOpacity(0.2)),
              ),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 32,
                    getTitlesWidget: (value, meta) => Text(
                      value.toInt().toString(),
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              ),
              lineBarsData: [
                LineChartBarData(
                  isCurved: true,
                  spots: spotsTemp,
                  barWidth: 2.5,
                  color: Colors.cyanAccent,
                  belowBarData: BarAreaData(show: true, color: Colors.cyanAccent.withOpacity(0.15)),
                  dotData: FlDotData(show: false),
                ),
                LineChartBarData(
                  isCurved: true,
                  spots: spotsRisk,
                  barWidth: 2,
                  color: Colors.pinkAccent,
                  belowBarData: BarAreaData(show: false),
                  dotData: FlDotData(show: false),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

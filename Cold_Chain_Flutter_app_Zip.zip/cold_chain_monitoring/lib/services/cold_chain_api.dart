import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/sensor_reading.dart';

class ColdChainApi {
  // Your ThingSpeak details
  static const _channelId = '3198815';
  static const _apiKey = '2YORPVQ8E7NMAKR5';
  static const _baseUrl = 'https://api.thingspeak.com/channels';

  /// Build the correct URL
  static Uri _buildUri({int results = 20}) {
    return Uri.parse(
      '$_baseUrl/$_channelId/feeds.json?api_key=$_apiKey&results=$results',
    );
  }

  /// Get latest N readings (used for dashboard + graph)
  static Future<List<SensorReading>> fetchRecentReadings({int results = 20}) async {
    final url = _buildUri(results: results);
    print('👉 Fetching from: $url');

    final res = await http.get(url);

    print('🔍 Status code: ${res.statusCode}');
    // Optional: print body if debugging
    // print('Body: ${res.body}');

    if (res.statusCode != 200) {
      throw Exception('Failed to fetch data: ${res.statusCode} – ${res.body}');
    }

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final feeds = data['feeds'] as List<dynamic>?;

    if (feeds == null || feeds.isEmpty) {
      print('⚠ No feeds returned from ThingSpeak');
      return [];
    }

    return feeds
        .map((f) => SensorReading.fromThingSpeak(f as Map<String, dynamic>))
        .toList();
  }

  /// Convenience: get only the latest reading
  static Future<SensorReading?> fetchLatestReading() async {
    final readings = await fetchRecentReadings(results: 1);
    if (readings.isEmpty) return null;
    return readings.first;
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;

class AnomalyService {
  final String baseUrl;  // e.g. 'http://10.0.2.2:5000' for Android emulator

  AnomalyService({this.baseUrl = "http://127.0.0.1:5000"});




  Future<Map<String, dynamic>> predictSingle(Map<String, dynamic> reading) async {
    final url = Uri.parse('$baseUrl/predict');
    final body = jsonEncode([reading]); // FastAPI expects a list
    final res = await http.post(url, headers: {'Content-Type': 'application/json'}, body: body);
    if (res.statusCode != 200) {
      throw Exception('Prediction failed: ${res.statusCode} ${res.body}');
    }
    final decoded = jsonDecode(res.body) as List<dynamic>;
    return Map<String, dynamic>.from(decoded.first as Map);
  }
}


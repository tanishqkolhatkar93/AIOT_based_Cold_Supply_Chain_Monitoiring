import '../models/sensor_reading.dart';

enum RiskLevel { normal, warning, high }

class RiskResult {
  final RiskLevel level;
  final String message;

  RiskResult(this.level, this.message);
}

RiskResult evaluateRisk(SensorReading current, {SensorReading? previous}) {
  // Rule 1: temperature-based
  if (current.temperature > 8) {
    return RiskResult(
      RiskLevel.high,
      'Temperature ${current.temperature.toStringAsFixed(1)}°C > 8°C – Spoilage risk!',
    );
  }

  // Rule 2: moisture-based
  if (current.moisture > 50) {
    return RiskResult(
      RiskLevel.high,
      'Moisture ${current.moisture}% > 50% – Possible leakage!',
    );
  }

  // Rule 3: distance change – door opened / theft
  if (previous != null) {
    final diff = current.distance - previous.distance;
    // distance ↑ = items removed or lid opened
    if (diff > 10) { // adjust threshold as per your tank height
      return RiskResult(
        RiskLevel.warning,
        'Distance increased by ${diff.toStringAsFixed(1)}cm – Possible door open or theft.',
      );
    }
  }

  // Optional: use spoilageRisk from MCU to override
  if (current.spoilageRisk >= 80) {
    return RiskResult(
      RiskLevel.high,
      'Spoilage risk from device: ${current.spoilageRisk}%.',
    );
  }

  return RiskResult(RiskLevel.normal, 'All conditions normal.');
}

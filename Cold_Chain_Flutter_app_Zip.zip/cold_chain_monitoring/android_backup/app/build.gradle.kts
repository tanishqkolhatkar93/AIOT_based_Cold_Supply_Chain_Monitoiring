// android/app/build.gradle
apply plugin: 'com.android.application'
apply plugin: 'kotlin-android'

android {
    compileSdkVersion 34

    defaultConfig {
        applicationId "com.example.yourapp" // <-- replace with your package id if different
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 1
        versionName "1.0"

        // If you use vector drawables on older devices:
        vectorDrawables.useSupportLibrary = true
    }

    buildTypes {
        release {
            // Enable ProGuard or R8 if required
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            // debug config
        }
    }

    // Enable Java 1.8 language features and core library desugaring
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
                targetCompatibility JavaVersion.VERSION_1_8
                coreLibraryDesugaringEnabled true
    }

    // If you use Kotlin in Android part, ensure jvmTarget is 1.8
    kotlinOptions {
        jvmTarget = "1.8"
    }

    // Optional: packaging options (avoid duplicate files errors)
    packagingOptions {
        resources {
            excludes += ['/META-INF/*.kotlin_module']
        }
    }
}

dependencies {
    implementation "org.jetbrains.kotlin:kotlin-stdlib:$kotlin_version"

    // Flutter generated plugin dependency is added automatically by Flutter.
    // Add core library desugaring implementation
    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.3'

    // If you explicitly need support libraries or other libs, list them here.
    // implementation 'com.some:library:version'
}

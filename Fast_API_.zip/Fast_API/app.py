# app.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from fastapi.middleware.cors import CORSMiddleware
import joblib
import pandas as pd
import os

# --- Configuration ---
MODEL_PATH = "isoforest_model (2).joblib"   # ensure this file exists
FEATURE_ORDER = ["temperature", "pressure", "distance", "moisture", "spoilageRisk"]

# --- Load model ---
if not os.path.exists(MODEL_PATH):
    raise RuntimeError(f"Model file not found at {MODEL_PATH}. Train the model first.")

model = joblib.load(MODEL_PATH)

# --- FastAPI app ---
app = FastAPI(title="IsolationForest Anomaly API")


# CORS middleware → allows Flutter/Web to call this API

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],            # narrow this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Request/response schemas ---

#All fields are optional (default = 0)     ,   FastAPI will auto-validate input

class Reading(BaseModel):
    temperature: Optional[float] = 0.0
    pressure:    Optional[float] = 0.0
    distance:    Optional[float] = 0.0
    moisture:    Optional[int]   = 0
    spoilageRisk: Optional[int]  = 0

class PredictionOut(BaseModel):
    prediction: int    # -1 anomaly, 1 normal
    score: float       # decision_function score

# Accept either a single reading or a list
@app.post("/predict", response_model=List[PredictionOut])
def predict(readings: List[Reading]):
    try:
        # convert to DataFrame and enforce feature order
        df = pd.DataFrame([r.model_dump() for r in readings])
        X = df.reindex(columns=FEATURE_ORDER).astype(float).values
        preds = model.predict(X)                # -1 or 1
        scores = model.decision_function(X)     # larger = more normal
        out = [{"prediction": int(p), "score": float(s)} for p, s in zip(preds, scores)]
        return out
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# convenience endpoint to check health
@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL_PATH}


